import numpy as np
import pandas as pd
import subprocess
import os
import glob

# Update the paths to point to the correct directory
TRANSCRIPT_DIR = r"G:\AV\PACKAGE 2\pres_ad_whisptranscripts"
METADATA_FNAME = r"G:\AV\PACKAGE 2\METADATA.csv"
VIDEO_DIR = r"G:\AV\PACKAGE 2\pres_ad_videos"
KEYFRAME_DIR = r"G:\AV\PACKAGE 2\keyframes_speechcentered"

# Print the directories being used for debugging purposes
print(f"Using METADATA_FILE: {METADATA_FNAME}")
print(f"Using TRANSCRIPT_DIR: {TRANSCRIPT_DIR}")
print(f"Using VIDEO_DIR: {VIDEO_DIR}")
print(f"Using KEYFRAME_DIR: {KEYFRAME_DIR}")

# Get the local transcription files
filepaths_transcripts_local = glob.glob(os.path.join(TRANSCRIPT_DIR, 'tsv', '*.tsv'))
transcribed_videos_local = [os.path.basename(x).split('.')[0] for x in filepaths_transcripts_local]

# Debugging step to confirm the found .tsv files
print(f"Found {len(transcribed_videos_local)} transcription files in the tsv directory.")

def run_ffmpeg_extract_frame(local_vid_fpath, frame_sample_time, image_output_fpath):
    """ Helper function to run ffmpeg for frame extraction """
    buffered_time = max(0, frame_sample_time - 1000)  # Buffer by 1 second (1000 ms)
    result = subprocess.run(
        ['ffmpeg', '-ss', str(buffered_time / 1000.), '-i', local_vid_fpath, '-frames:v', '1', image_output_fpath, '-y', '-hide_banner', '-loglevel', 'error'],
        capture_output=True, text=True
    )
    return result

if __name__ == '__main__':
    # Create keyframe storage directory if it doesn't already exist
    if not os.path.exists(KEYFRAME_DIR): 
        os.makedirs(KEYFRAME_DIR)

    # Read metadata
    metadata_df = pd.read_csv(METADATA_FNAME)

    for idx in range(len(metadata_df)):
        vid_fname = metadata_df['FILENAME'].values[idx]
        tsv_path = os.path.join(TRANSCRIPT_DIR, 'tsv', vid_fname.split('.')[0] + '.tsv')
        local_vid_fpath = os.path.join(VIDEO_DIR, vid_fname)  # Define the local path to the video file

        print(f"Processing video {vid_fname}...")
        print(f"Constructed TSV path: {tsv_path}")
        print(f"Constructed Video path: {local_vid_fpath}")

        # Skip if the .tsv file is not available
        if not os.path.isfile(tsv_path):
            print(f"ERROR: TSV file not found at path: {tsv_path}. Skipping {vid_fname}.")
            continue

        try:
            # Read the transcript and extract segment times
            tsv = pd.read_csv(tsv_path, sep='\t')

            # If no segments exist, skip the video
            if tsv.empty:
                print(f"ERROR: No segments found in TSV for {vid_fname}. Skipping.")
                continue

            segment_starts = tsv['start'].values
            segment_ends = tsv['end'].values
            segment_middles = [int(segment_starts[ii] + (segment_ends[ii] - segment_starts[ii]) / 2.0) for ii in range(len(segment_starts))]

            # Check if the last frame is already saved, skip if so
            last_image_path = os.path.join(KEYFRAME_DIR, str(vid_fname.split('.')[0]) + "_" + str(segment_middles[-1]) + ".jpg")
            if os.path.isfile(last_image_path):
                print(f"Skipping {vid_fname}, keyframes already generated.")
                continue

            # Extract frames at the middle of each segment
            for fidx, frame_sample_time in enumerate(segment_middles):
                if frame_sample_time > metadata_df['DURATION'].values[idx] * 1000.:
                    print(f"Skipping frame {fidx}, as it exceeds video duration.")
                    continue

                image_output_fpath = os.path.join(KEYFRAME_DIR, f"{vid_fname.split('.')[0]}_{frame_sample_time}.jpg")

                # Run ffmpeg to extract the frame
                result = run_ffmpeg_extract_frame(local_vid_fpath, frame_sample_time, image_output_fpath)

                # Check for ffmpeg errors
                if result.returncode != 0:
                    print(f"ERROR: ffmpeg failed for video {local_vid_fpath} at time {frame_sample_time / 1000.0}s.")
                    print(f"ffmpeg stderr: {result.stderr}")
                    continue  # Skip this frame if ffmpeg failed

                print(f"Saved frame to: {image_output_fpath}")

        except Exception as e:
            print(f"ERROR while processing {tsv_path}. Exception: {e}")
            continue
