from transformers import AutoModelForCausalLM, AutoTokenizer
import numpy as np
import pandas as pd
import os
import glob
from mpi4py import MPI
from datetime import datetime
import sys

# Load the model and tokenizer from Hugging Face
model_name = "gpt2"  # or "distilgpt2"
print(f"Loading model: {model_name}")
model = AutoModelForCausalLM.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

def send_frame_to_gpt(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT):
    # Limit the transcript length to avoid overwhelming the model
    transcript_excerpt = TRANSCRIPT[:300]  # Take the first 300 characters for brevity
    
    prompt = (f'Describe what is depicted in this video frame in no more than 15 words. '
              f'Do not state that the frame depicts a vintage advertisement, and do not comment on the image quality. '
              f'If the image includes text, then state that it includes text and also include a summary of the text that is shown. '
              f'For context, this video frame is a still taken from an advertisement for the {ELECTION_YEAR} presidential campaign of {PARTY} {CANDIDATE}. '
              f'The transcript of the entire ad is:\n {transcript_excerpt}')
    
    inputs = tokenizer(prompt, return_tensors="pt")
    
    # Adjust generation parameters
    outputs = model.generate(
        inputs["input_ids"], 
        max_new_tokens=50,  # Control response length
        do_sample=True,  # Enable sampling for variability
        temperature=0.7,
        top_k=50,
        pad_token_id=tokenizer.eos_token_id  # Proper padding for GPT-2
    )
    
    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    # Ensure the result is no more than 15 words
    result = ' '.join(result.split()[:15])
    return result

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    # Ensure proper arguments
    if len(sys.argv) != 8:
        if rank == 0:
            print("Usage: python step3_describe_keyframes.py <KEYFRAMES_SPEECH_DIR> <KEYFRAMES_REG_DIR> "
                  "<FRAME_DESC_SPEECH_DIR> <FRAME_DESC_REG_DIR> <TRANSCRIPT_DIR> <VIDEO_DIR> <METADATA_FILE>")
        sys.exit(1)

    KEYFRAMES_SPEECH_DIR = sys.argv[1]
    KEYFRAMES_REG_DIR = sys.argv[2]
    FRAME_DESC_SPEECH_DIR = sys.argv[3]
    FRAME_DESC_REG_DIR = sys.argv[4]
    TRANSCRIPT_DIR = sys.argv[5]
    VIDEO_DIR = sys.argv[6]
    METADATA_FNAME = os.path.abspath(sys.argv[7])

    print(f"Rank {rank}: Processing metadata from {METADATA_FNAME}")

    # Initialize output directory
    DIRECTORY_SUFFIX = 'speechcentered'
    input_directory = 'keyframes_' + DIRECTORY_SUFFIX
    output_directory = 'GPT_frame_descriptions_' + DIRECTORY_SUFFIX

    if rank == 0:
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)
            print(f"Created output directory: {output_directory}")
    comm.Barrier()

    # Load metadata
    metadata_df = pd.read_csv(METADATA_FNAME)
    already_donebyGPT_frames = set(glob.glob(os.path.join(output_directory, '*.txt')))
    tot_num_frames_to_do = len(glob.glob(os.path.join(input_directory, '*')))
    num_frames_left_to_do = tot_num_frames_to_do - len(already_donebyGPT_frames)

    print(f"Rank {rank}: Total frames to process: {tot_num_frames_to_do}. Remaining: {num_frames_left_to_do}")

    # Parallel split
    indices = list(range(len(metadata_df)))
    np.random.shuffle(indices)
    local_mastercsv_idx_split = np.array_split(indices, size)[rank]
    totcount_of_frames_processed_thisproc = 0

    for local_count, idx in enumerate(local_mastercsv_idx_split):
        vid_fname = metadata_df['FILENAME'].values[idx]
        vid_basename = os.path.splitext(vid_fname)[0]

        print(f"Rank {rank}: Processing video {vid_basename}")

        # Fetch transcript
        transcript_txt_path = os.path.join(TRANSCRIPT_DIR, 'txt', vid_basename + '.txt')
        if not os.path.isfile(transcript_txt_path):
            print(f"Rank {rank}: Transcript not found for {vid_basename}. Skipping.")
            continue

        with open(transcript_txt_path, "r") as text_file:
            TRANSCRIPT = text_file.read()

        PARTY = metadata_df['PARTY'].values[idx]
        ELECTION_YEAR = str(metadata_df['ELECTION'].values[idx])
        CANDIDATE = f"{metadata_df['FIRST_NAME'].values[idx]} {metadata_df['LAST_NAME'].values[idx]}".strip()

        # Process keyframes
        for this_frame_fpath in glob.glob(os.path.join(input_directory, vid_basename + '*')):
            output_file_name = os.path.basename(this_frame_fpath) + '.txt'
            output_file_path = os.path.join(output_directory, output_file_name)

            if output_file_path in already_donebyGPT_frames:
                print(f"Rank {rank}: Frame {output_file_name} already processed. Skipping.")
                continue

            try:
                print(f"Rank {rank}: Processing frame {output_file_name}")
                result = send_frame_to_gpt(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT)
                with open(output_file_path, 'w') as outfile:
                    outfile.write(result)
                print(f"Rank {rank}: Frame description saved to {output_file_path}")
            except Exception as e:
                print(f"Rank {rank}: Error processing {os.path.basename(this_frame_fpath)}: {e}")
                continue
