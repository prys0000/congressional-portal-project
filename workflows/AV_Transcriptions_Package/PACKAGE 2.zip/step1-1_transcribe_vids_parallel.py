import os
import sys
import numpy as np
from datetime import datetime
import subprocess
import glob
import json
import soundfile as sf
from vosk import Model, KaldiRecognizer

# Load Vosk model
vosk_model_path = r"G:\AV\PACKAGE 2\vosk-model"
if not os.path.exists(vosk_model_path):
    print("Please download the Vosk model from 'https://alphacephei.com/vosk/models' and unzip it into 'vosk-model' directory.")
    sys.exit(1)

print(f"Loading Vosk model from {vosk_model_path}...")
model = Model(vosk_model_path)
print("Vosk model loaded successfully.")

def check_wav_file(wav_path):
    """ Check if the WAV file has been correctly generated """
    if not os.path.exists(wav_path):
        raise FileNotFoundError(f"WAV file not found: {wav_path}")
    try:
        with sf.SoundFile(wav_path) as f:
            print(f"WAV file info - frames: {f.frames}, samplerate: {f.samplerate}, channels: {f.channels}")
            if f.frames == 0:
                raise ValueError(f"Empty WAV file: {wav_path}")
    except Exception as e:
        raise ValueError(f"Error opening WAV file: {wav_path} - {e}")

def run_ffmpeg_conversion(vid_fpath, wav_fpath):
    """ Convert video to WAV format using ffmpeg """
    print(f"Converting video to WAV: {vid_fpath}")
    command = ["ffmpeg", "-i", vid_fpath, "-ar", "16000", "-ac", "1", wav_fpath]
    ffmpeg_result = subprocess.run(command, capture_output=True, text=True)
    
    if ffmpeg_result.returncode != 0:
        print(f"Error converting {vid_fpath} to WAV: {ffmpeg_result.stderr}")
        return False
    print(f"WAV conversion successful: {wav_fpath}")
    return True

if __name__ == '__main__':
    time_start = datetime.now()
    error_files_thisproc = []
    error_msgs_thisproc = []
    vid_count = 0

    # Check command-line arguments
    if len(sys.argv) < 3:
        print("Usage: python step1_transcribe_vids_parallel.py <video_directory> <transcript_output_directory>")
        sys.exit(1)

    # Parse command-line arguments
    video_directory = os.path.abspath(sys.argv[1])
    transcript_output_directory = os.path.abspath(sys.argv[2])

    print(f"Video directory: {video_directory}")
    print(f"Transcript output directory: {transcript_output_directory}")

    # Define subdirectories for transcripts
    json_transcript_dir = os.path.join(transcript_output_directory, "json")
    tsv_transcript_dir = os.path.join(transcript_output_directory, "tsv")
    txt_transcript_dir = os.path.join(transcript_output_directory, "txt")

    # Ensure directories exist
    os.makedirs(json_transcript_dir, exist_ok=True)
    os.makedirs(tsv_transcript_dir, exist_ok=True)
    os.makedirs(txt_transcript_dir, exist_ok=True)

    # Collect video file paths
    vidfilepaths_local = glob.glob(os.path.join(video_directory, '*.mp4'))
    vidfilepaths_local = [os.path.normpath(vid_fpath) for vid_fpath in vidfilepaths_local]

    # Process each video
    for vid_fpath in vidfilepaths_local:
        vid_fpath_id = os.path.splitext(os.path.basename(vid_fpath))[0]
        print(f"Processing video: {vid_fpath_id}")

        # Convert video to audio (e.g., WAV format for transcription)
        wav_fpath = os.path.join(transcript_output_directory, f"{vid_fpath_id}.wav")
        if not run_ffmpeg_conversion(vid_fpath, wav_fpath):
            error_files_thisproc.append(vid_fpath_id)
            continue

        # Check if the WAV file is valid
        try:
            check_wav_file(wav_fpath)
        except (FileNotFoundError, ValueError) as e:
            print(f"[ERROR] Issue with WAV file: {e}")
            error_files_thisproc.append(vid_fpath_id)
            continue

        # Transcription and word timings
        try:
            print(f"Starting transcription for: {wav_fpath}")
            with sf.SoundFile(wav_fpath) as audio_file:
                recognizer = KaldiRecognizer(model, audio_file.samplerate)
                recognizer.SetWords(True)  # Enable word-level transcription
                transcription = ""
                word_timings = []  # To store word timings for the TSV file

                while True:
                    data = audio_file.read(4000, dtype='int16')
                    if len(data) == 0:
                        break
                    if recognizer.AcceptWaveform(data.tobytes()):
                        result = json.loads(recognizer.Result())
                        transcription += result["text"] + " "

                        # Capture word timings if available
                        if 'result' in result:
                            for word_info in result['result']:
                                word_timings.append([
                                    word_info['start'],  # Start time
                                    word_info['end'],    # End time
                                    word_info['word']    # The actual word
                                ])
                    else:
                        # Handle partial result (if Vosk processes longer than expected segments)
                        print(f"[INFO] Partial result: {recognizer.PartialResult()}")

            # Check if transcription contains any words, otherwise note that there's no speech
            if not transcription.strip():
                transcription = "[No speech detected in the video]"

            # Save the text transcript
            txt_path = os.path.join(txt_transcript_dir, vid_fpath_id + '.txt')
            with open(txt_path, "w") as text_file:
                text_file.write(transcription)

            # Save JSON transcript
            json_path = os.path.join(json_transcript_dir, vid_fpath_id + '.json')
            with open(json_path, 'w') as json_file:
                json.dump({"text": transcription}, json_file)

            # Save word timings as a TSV file if word timings exist
            tsv_path = os.path.join(tsv_transcript_dir, vid_fpath_id + '.tsv')
            if word_timings:
                with open(tsv_path, 'w') as tsv_file:
                    tsv_file.write("start\tend\tword\n")  # Header
                    for word_info in word_timings:
                        tsv_file.write(f"{word_info[0]}\t{word_info[1]}\t{word_info[2]}\n")
                print(f"Word timings saved to {tsv_path}")
            else:
                print(f"[INFO] No word timings captured for {vid_fpath_id}, creating an empty TSV.")
                with open(tsv_path, 'w') as tsv_file:
                    tsv_file.write("start\tend\tword\n")  # Create empty TSV with header

        except Exception as e:
            error_files_thisproc.append(vid_fpath_id)
            error_msgs_thisproc.append(str(e))
            print(f"ERROR processing file: {vid_fpath_id}, Error: {e}")
            continue

        vid_count += 1

    # Summary of errors
    print(f"Completed {vid_count} videos with {len(error_files_thisproc)} errors.")
    if error_files_thisproc:
        print(f"Errors occurred on the following files: {error_files_thisproc}")
