import numpy as np
from datetime import datetime
import pandas as pd
import subprocess
import os
import glob
from mpi4py import MPI

"""
This script saves a still frame at evenly time-spaced intervals from each ad video.
"""

METADATA_FNAME = 'METADATA.csv'  # Ensure this file exists
VIDEO_DIR = 'pres_ad_videos'  # Video directory
KEYFRAME_DIR = 'keyframes_regintervals'  # Directory to store keyframes

def get_video_duration(video_path):
    """Get the duration of the video using ffmpeg"""
    result = subprocess.run(
        ['ffmpeg', '-i', video_path, '-hide_banner'],
        capture_output=True, text=True, stderr=subprocess.STDOUT
    )
    for line in result.stdout.splitlines():
        if 'Duration' in line:
            duration_str = line.split(',')[0].split('Duration:')[1].strip()
            h, m, s = duration_str.split(':')
            total_seconds = int(h) * 3600 + int(m) * 60 + float(s)
            return total_seconds * 1000  # return in milliseconds
    return 0  # If unable to retrieve duration

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    # Create keyframe storage directory if it doesn't already exist:
    if rank == 0:
        if not os.path.exists(KEYFRAME_DIR):
            os.makedirs(KEYFRAME_DIR)

    proc_time0 = datetime.now()
    local_errors = []

    # Load the metadata file
    metadata_df = pd.read_csv(METADATA_FNAME)

    # Split the metadata across processes
    local_mastercsv_idx_split = np.array_split(list(range(len(metadata_df))), size)[rank]

    for local_count, idx in enumerate(local_mastercsv_idx_split):
        if local_count > 1:
            proc_elapsed_min = (datetime.now() - proc_time0).total_seconds() / 60.0
            print(f'\nRank {rank} starting CSV row {idx}, local workload {local_count} of {len(local_mastercsv_idx_split)}, '
                  f'Elapsed: {proc_elapsed_min:.2f} min, Remaining: '
                  f'{proc_elapsed_min * (len(local_mastercsv_idx_split) - local_count) / local_count:.2f} mins')

        vid_fname = metadata_df['FILENAME'].values[idx]
        local_vid_fpath = os.path.join(VIDEO_DIR, vid_fname)  # Construct full video path

        if not os.path.isfile(local_vid_fpath):
            print(f"ERROR: Video file not found: {local_vid_fpath}")
            local_errors.append([rank, f"Video file not found: {local_vid_fpath}"])
            continue

        print(f"Processing video: {local_vid_fpath}")

        try:
            # Get video duration
            video_duration = get_video_duration(local_vid_fpath)
            if video_duration == 0:
                print(f"ERROR: Unable to retrieve duration for {local_vid_fpath}")
                local_errors.append([rank, f"Unable to retrieve duration for {local_vid_fpath}"])
                continue

            print(f"Video duration: {video_duration / 1000.0:.2f} seconds")

            # Take frames at 3-sec intervals until video end is reached:
            for frame_sample_time in range(3000, int(video_duration), 3000):  # Adjust range based on video length
                image_output_fpath = os.path.join(KEYFRAME_DIR, f"{vid_fname}_{frame_sample_time}.jpg")
                
                # Skip extraction if the frame already exists
                if os.path.isfile(image_output_fpath):
                    print(f"Frame {image_output_fpath} already exists. Skipping.")
                    continue
                
                # Execute ffmpeg to extract frames
                result = subprocess.run(
                    ['ffmpeg', '-ss', str(frame_sample_time / 1000.0), '-i', local_vid_fpath,
                     '-frames:v', '1', image_output_fpath, '-y', '-hide_banner', '-loglevel', 'warning'],
                    capture_output=True, text=True
                )

                # Check for ffmpeg errors
                if result.returncode == 0:
                    print(f"Frame saved: {image_output_fpath}")
                else:
                    print(f"ERROR: ffmpeg failed on {local_vid_fpath} at {frame_sample_time / 1000.0} sec.")
                    print(f"ffmpeg stderr: {result.stderr}")
                    local_errors.append([rank, f"ffmpeg error on {local_vid_fpath}"])
                    # Continue processing the next frames even if one frame fails
                    continue

        except Exception as e:
            print(f"ERROR: {e}, processor {rank}, video {local_vid_fpath}")
            local_errors.append([rank, e, local_vid_fpath])
            continue

    # Print all errors collected at the end
    if local_errors:
        print(f"Rank {rank} encountered errors:", local_errors)
