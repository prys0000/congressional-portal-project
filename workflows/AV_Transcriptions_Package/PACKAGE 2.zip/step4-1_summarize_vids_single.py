import os
import sys
import numpy as np
import pandas as pd
from datetime import datetime
import glob
from transformers import AutoModelForCausalLM, AutoTokenizer

"""
This script summarizes videos in a single process using GPT-J from Hugging Face.
"""

# Ensure the correct number of command-line arguments
if len(sys.argv) != 6:
    print("Usage: python step4_summarize_vids_single.py <TRANSCRIPT_DIR> <FRAME_DESC_SPEECH_DIR> "
          "<FRAME_DESC_REG_DIR> <VIDEO_DIR> <METADATA_FILE>")
    sys.exit(1)

# Parsing command line arguments
TRANSCRIPT_DIR = sys.argv[1].replace('\\', '/')
FRAME_DESC_SPEECH_DIR = sys.argv[2]
FRAME_DESC_REG_DIR = sys.argv[3]
VIDEO_DIR = sys.argv[4]
METADATA_FNAME = os.path.abspath(sys.argv[5])

print(f"[INFO] Transcript directory: {TRANSCRIPT_DIR}")
print(f"[INFO] Video directory: {VIDEO_DIR}")
print(f"[INFO] Metadata file: {METADATA_FNAME}")

# Load the model and tokenizer from Hugging Face
model_name = "EleutherAI/gpt-j-6B"
print(f"[INFO] Loading model: {model_name}")

try:
    model = AutoModelForCausalLM.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    print(f"[INFO] Model {model_name} loaded successfully.")
except Exception as e:
    print(f"[ERROR] Error loading model {model_name}: {e}")
    sys.exit(1)

def gpt_summarize_ad(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT, FRAMETIMES, FRAMEDESCRIPTIONS, response_wordcount=50):
    try:
        FRAMETIMES_argsort = np.argsort(FRAMETIMES)
        FRAMEDESCRIPTIONS_timesorted = np.asarray(FRAMEDESCRIPTIONS)[FRAMETIMES_argsort]

        prompt = (
            f"Provide a {response_wordcount}-word summary of a political television ad for the academic community. "
            f"Your summary should not exceed {response_wordcount} words. For context, this ad was for the {ELECTION_YEAR} "
            f"presidential campaign of {PARTY} candidate {CANDIDATE}. The transcript of the entire ad is:\n{TRANSCRIPT[:500]}\n\n"  # Limit transcript to 500 chars
            f"The ad video depicts a set of scenes that can be described as follows:\n\n" +
            '\n\n'.join([f'Scene {idx+1}: {segment}' for idx, segment in enumerate(FRAMEDESCRIPTIONS_timesorted)])
        )

        print(f"[INFO] Sending prompt to GPT-J for {CANDIDATE} ({ELECTION_YEAR})")

        # Convert the prompt to tokens and generate the summary using GPT-J
        inputs = tokenizer(prompt, return_tensors="pt")
        outputs = model.generate(inputs["input_ids"], max_new_tokens=100, temperature=0.7, top_k=50)  # Set max_new_tokens instead of max_length
        result = tokenizer.decode(outputs[0], skip_special_tokens=True)

        # Ensure the result doesn't include any unwanted prompts
        result_cleaned = result.replace("Describe what is depicted in this video frame in no more than 15 words.", "").strip()

        # Ensure the result doesn't exceed the desired word count
        result_cleaned = ' '.join(result_cleaned.split()[:response_wordcount])

        return result_cleaned
    except Exception as e:
        print(f"[ERROR] GPT-J summarization failed: {e}")
        return ""

if __name__ == '__main__':
    # Create the output directory if it doesn't exist
    output_dir = "GPT_video_summaries"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    print(f"[INFO] Output directory: {output_dir}")

    # Check already summarized videos
    already_summarized_videos = glob.glob(os.path.join(output_dir, '*.txt'))
    print(f"[INFO] Found {len(already_summarized_videos)} already summarized videos.")

    # Load metadata
    metadata_df = pd.read_csv(METADATA_FNAME)
    print(f"[INFO] Loaded metadata. Total rows: {len(metadata_df)}")

    proc_time0 = datetime.now()
    local_errors = []
    already_done = 0

    for idx in range(len(metadata_df)):
        vid_fname = metadata_df['FILENAME'].values[idx]
        vid_basename = os.path.splitext(vid_fname)[0]
        summary_output_path = os.path.join(output_dir, vid_fname + '.txt')

        if summary_output_path in already_summarized_videos:
            already_done += 1
            continue

        PARTY = metadata_df['PARTY'].values[idx]
        ELECTION_YEAR = str(metadata_df['ELECTION'].values[idx])

        lastname = metadata_df['LAST_NAME'].values[idx] if pd.notnull(metadata_df['LAST_NAME'].values[idx]) else ''
        firstname = metadata_df['FIRST_NAME'].values[idx] if pd.notnull(metadata_df['FIRST_NAME'].values[idx]) else ''
        CANDIDATE = f"{firstname} {lastname}".strip()

        print(f"[INFO] Processing video: {CANDIDATE} ({ELECTION_YEAR})")

        # Fetch transcript
        transcript_txt_path = os.path.join(TRANSCRIPT_DIR, 'txt', vid_basename + '.txt')
        if not os.path.isfile(transcript_txt_path):
            print(f"[ERROR] Transcript file not found: {transcript_txt_path}")
            continue

        with open(transcript_txt_path, "r") as text_file:
            TRANSCRIPT = text_file.read()

        if pd.isnull(TRANSCRIPT) or TRANSCRIPT.strip() == "":
            TRANSCRIPT = 'null, as no words are spoken in the ad'

        # Load frame descriptions for speech-centered and regular interval frames
        FRAMETIMES, FRAMEDESCRIPTIONS = [], []
        for desc_dir, desc_list, time_list in [(FRAME_DESC_SPEECH_DIR, FRAMEDESCRIPTIONS, FRAMETIMES),
                                               (FRAME_DESC_REG_DIR, FRAMEDESCRIPTIONS, FRAMETIMES)]:
            frame_files = glob.glob(os.path.join(desc_dir, vid_basename + '*'))
            print(f"[INFO] Found {len(frame_files)} frame description files in {desc_dir}")
            for this_framedescription_fpath in frame_files:
                frametime = float(this_framedescription_fpath.split('_')[-1].split('.')[0])
                with open(this_framedescription_fpath, 'r') as tmp:
                    description = tmp.read()
                    desc_list.append(description)
                    time_list.append(frametime)

        if not FRAMEDESCRIPTIONS:
            print(f"[ERROR] No frame descriptions found for video: {vid_fname}")
            continue

        try:
            time0 = datetime.now()
            result = gpt_summarize_ad(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT, FRAMETIMES, FRAMEDESCRIPTIONS)

            if not result.strip():
                raise Exception("[ERROR] Empty result from GPT-J")

            with open(summary_output_path, 'w') as outfile:
                outfile.write(result)
            print(f"[INFO] Processed {vid_fname}. Time: {(datetime.now() - time0).total_seconds()} sec")

        except Exception as e:
            print(f'[ERROR] Encountered an error on {vid_fname}: {e}')
            local_errors.append((e, vid_fname))

    print(f"[INFO] Completed processing. Already done: {already_done}")
    if local_errors:
        print(f"[ERROR] Encountered errors: {local_errors}")
