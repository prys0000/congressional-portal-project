import numpy as np
from datetime import datetime
import pandas as pd
from mpi4py import MPI
import subprocess
import whisper
from whisper.utils import get_writer
import glob
import os
import sys  # For command-line arguments

"""
This script whisper-transcribes videos in parallel.
"""

# Load the Whisper model once at the top-level scope
whispermodel = whisper.load_model("large-v3")

# Options for the transcript writer
options = {
    'max_line_width': None,
    'max_line_count': None,
    'highlight_words': False
}

if __name__ == '__main__':
    # Initialize MPI
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    time_start = datetime.now()
    error_files_thisproc = []
    error_msgs_thisproc = []
    vid_count = 0

    # Check command-line arguments
    if len(sys.argv) < 3:
        if rank == 0:
            print("Usage: python step1_transcribe_vids_parallel.py <video_directory> <transcript_output_directory>")
        sys.exit(1)

    # Parse command-line arguments
    video_directory = sys.argv[1]
    transcript_output_directory = sys.argv[2]

    # Ensure the directories are absolute paths
    video_directory = os.path.abspath(video_directory)
    transcript_output_directory = os.path.abspath(transcript_output_directory)

    # Define subdirectories for transcripts
    json_transcript_dir = os.path.join(transcript_output_directory, "json")
    tsv_transcript_dir = os.path.join(transcript_output_directory, "tsv")
    txt_transcript_dir = os.path.join(transcript_output_directory, "txt")

    # Root processor checks and creates directories
    if rank == 0:
        # Check if video directory exists
        if not os.path.exists(video_directory):
            raise Exception(f"Error: Video directory '{video_directory}' does not exist.")

        print(f"Rank {rank}: video_directory = {video_directory}")

        # Create transcript storage directories if they don't already exist
        os.makedirs(json_transcript_dir, exist_ok=True)
        os.makedirs(tsv_transcript_dir, exist_ok=True)
        os.makedirs(txt_transcript_dir, exist_ok=True)

    # Broadcast the directories to all processes
    video_directory = comm.bcast(video_directory, root=0)
    json_transcript_dir = comm.bcast(json_transcript_dir, root=0)
    tsv_transcript_dir = comm.bcast(tsv_transcript_dir, root=0)
    txt_transcript_dir = comm.bcast(txt_transcript_dir, root=0)

    # Collect video file paths
    vidfilepaths_local = glob.glob(os.path.join(video_directory, '*.mp4'))
    vidfilepaths_local = [os.path.normpath(vid_fpath) for vid_fpath in vidfilepaths_local]

    # Collect existing transcript files to avoid re-processing
    filepaths_transcripts_local = glob.glob(os.path.join(json_transcript_dir, '*.json'))
    transcribed_videos_local = [os.path.splitext(os.path.basename(x))[0] for x in filepaths_transcripts_local]

    if rank == 0:
        print('Total video count:', len(vidfilepaths_local))
        print('Total transcript count:', len(transcribed_videos_local))

    # Get the base filenames without extension
    all_vid_fpaths = [os.path.splitext(os.path.basename(vid_fpath))[0] for vid_fpath in vidfilepaths_local]

    # Determine videos left to process
    all_vid_fpaths_LEFTTODO = list(set(all_vid_fpaths).difference(transcribed_videos_local))

    # Distribute the work among processes
    this_proc_left_to_do = np.array_split(all_vid_fpaths_LEFTTODO, size)[rank]

    # Process each video assigned to this process
    for idx, vid_fpath_id in enumerate(this_proc_left_to_do):
        # Construct the full path to the video file
        vid_fpath = os.path.join(video_directory, vid_fpath_id + '.mp4')

        # Debug print statements
        print(f"Rank {rank}: Processing file: vid_fpath_id = {vid_fpath_id}, vid_fpath = {vid_fpath}")

        # Transcribe the video
        try:
            transcription = whispermodel.transcribe(vid_fpath, fp16=False)

            # Save the text transcript
            with open(os.path.join(txt_transcript_dir, vid_fpath_id + '.txt'), "w") as text_file:
                text_file.write(transcription['text'])

            # Save TSV and JSON transcripts
            tsv_writer = get_writer("tsv", tsv_transcript_dir)
            tsv_writer(transcription, vid_fpath_id + '.tsv', options)
            json_writer = get_writer("json", json_transcript_dir)
            json_writer(transcription, vid_fpath_id + '.json', options)

        except Exception as e:
            error_files_thisproc.append(vid_fpath_id)
            error_msgs_thisproc.append(str(e))
            print(f'ERROR processing file: {vid_fpath_id}, Error: {e}')
            continue  # Skip to the next file

        vid_count += 1
        elapsed = (datetime.now() - time_start).total_seconds()
        remaining_time = ((elapsed / vid_count) * (len(this_proc_left_to_do) - vid_count)) / 60.0
        print(f'\nRank {rank} Completed {vid_count} of {len(this_proc_left_to_do)} videos, '
              f'Elapsed: {elapsed // 60} minutes, Remaining time: {remaining_time:.2f} minutes, '
              f'Errors: {len(error_files_thisproc)}')

    # Gather errors from all processes
    error_messages = comm.gather(error_msgs_thisproc, root=0)
    error_files = comm.gather(error_files_thisproc, root=0)

    if rank == 0:
        print('\nError messages from all processes:')
        for i, (proc_errors, proc_files) in enumerate(zip(error_messages, error_files)):
            if proc_errors:
                print(f'Process {i} had errors with files: {proc_files}')
                for msg in proc_errors:
                    print(f'Error: {msg}')
        else:
            print('No errors encountered.')
