import os
os.environ["NUMEXPR_MAX_THREADS"] = "272"

import openai
import numpy as np
import pandas as pd
from datetime import datetime
from time import sleep
import base64
import glob
import json
import sys
from mpi4py import MPI

"""
This script describes keyframes using GPT-4 with text-based input.
"""

# Ensure the correct number of command-line arguments
if len(sys.argv) != 8:
    print("Usage: python step3_describe_keyframes.py <KEYFRAMES_SPEECH_DIR> <KEYFRAMES_REG_DIR> "
          "<FRAME_DESC_SPEECH_DIR> <FRAME_DESC_REG_DIR> <TRANSCRIPT_DIR> <VIDEO_DIR> <METADATA_FILE>")
    sys.exit(1)

KEYFRAMES_SPEECH_DIR = sys.argv[1]
KEYFRAMES_REG_DIR = sys.argv[2]
FRAME_DESC_SPEECH_DIR = sys.argv[3]
FRAME_DESC_REG_DIR = sys.argv[4]
TRANSCRIPT_DIR = sys.argv[5]
VIDEO_DIR = sys.argv[6]
METADATA_FNAME = os.path.abspath(sys.argv[7])

MY_OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not MY_OPENAI_API_KEY:
    raise Exception("Please set the OPENAI_API_KEY environment variable.")

openai.api_key = MY_OPENAI_API_KEY

# APPLY WORKFLOW TO PROCESS SPEECH SEGMENT KEYFRAMES OR REGULAR INTERVAL KEYFRAMES?
DIRECTORY_SUFFIX = 'speechcentered'

print('Working on', DIRECTORY_SUFFIX, 'keyframes. Change this in the script to switch between speech-centered or regular intervals.')

input_directory = 'keyframes_' + DIRECTORY_SUFFIX
output_directory = 'GPT_frame_descriptions_' + DIRECTORY_SUFFIX

def send_frame_to_gpt(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT):
    prompt = (f'Describe what is depicted in this video frame in no more than 15 words. '
              f'Do not state that the frame depicts a vintage advertisement, and do not comment on the image quality. '
              f'If the image includes text, then state that it includes text and also include a summary of the text that is shown. '
              f'For context, this video frame is a still taken from an advertisement for the {ELECTION_YEAR} presidential campaign of {PARTY} {CANDIDATE}. '
              f'The transcript of the entire ad is:\n {TRANSCRIPT}')
    
    if 'anti' in CANDIDATE.lower():
        prompt = (f'Describe what is depicted in this video frame in no more than 15 words. '
                  f'Do not state that the frame depicts a vintage advertisement, and do not comment on the image quality. '
                  f'If the image includes text, then state that it includes text and also include a summary of the text that is shown. '
                  f'For context, this video frame is a still taken from an advertisement for the {ELECTION_YEAR} presidential election. '
                  f'This ad is anti-{CANDIDATE} and pro-{PARTY}. '
                  f'The transcript of the entire ad is:\n {TRANSCRIPT}')
    
    print('\n\n', prompt, '\n')

    # Create the request with text-based prompt
    PROMPT_MESSAGES = [
        {"role": "user", "content": prompt}
    ]

    parameters = {
        "model": "gpt-4",
        "messages": PROMPT_MESSAGES,
        "max_tokens": 1000,
    }

    result = openai.ChatCompletion.create(**parameters)
    return result.choices[0].message.content

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    print(rank, size)

    # Initialize output storage directory if it doesn't exist
    if rank == 0:
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)
    comm.Barrier()  # Ensure directory creation is completed before proceeding

    sleep(rank * 0.2)  # Avoid rate limit issue that arises when all procs make first API query simultaneously.

    metadata_df = pd.read_csv(METADATA_FNAME)

    already_donebyGPT_frames = set(glob.glob(os.path.join(output_directory, '*.txt')))
    tot_num_frames_to_do = len(glob.glob(os.path.join(input_directory, '*')))
    num_frames_left_to_do = tot_num_frames_to_do - len(already_donebyGPT_frames)

    # Parallel split here
    proc_time0 = datetime.now()
    indices = list(range(len(metadata_df)))
    np.random.shuffle(indices)  # Randomly reshuffle these to better load balance across processors
    local_mastercsv_idx_split = np.array_split(indices, size)[rank]  # Each proc gets a list of CSV row indices we want to process

    totcount_of_frames_processed_thisproc = 0
    already_done = 0
    for local_count, idx in enumerate(local_mastercsv_idx_split):
        if local_count > 1:
            proc_elapsed_min = (datetime.now() - proc_time0).total_seconds() / 60.0
            print('\nRank', rank, 'starting CSV row', idx, 'which is local workload', local_count, 'of',
                  len(local_mastercsv_idx_split), 'in', proc_elapsed_min, 'min;',
                  proc_elapsed_min * float(len(local_mastercsv_idx_split) - local_count) / float(local_count), 'mins remain')

        vid_fname = metadata_df['FILENAME'].values[idx]
        local_vid_fpath = os.path.join(VIDEO_DIR, vid_fname)

        PARTY = metadata_df['PARTY'].values[idx]
        ELECTION_YEAR = str(metadata_df['ELECTION'].values[idx])
        print("metadata_df['FIRST_NAME'].values[idx]", metadata_df['FIRST_NAME'].values[idx],
              "metadata_df['LAST_NAME'].values[idx]", metadata_df['LAST_NAME'].values[idx])
        lastname = metadata_df['LAST_NAME'].values[idx] if pd.notnull(metadata_df['LAST_NAME'].values[idx]) else ''
        firstname = metadata_df['FIRST_NAME'].values[idx] if pd.notnull(metadata_df['FIRST_NAME'].values[idx]) else ''
        CANDIDATE = f"{firstname} {lastname}".strip()

        # Debug: Print all .txt files detected in the directory
        print("Transcript files detected in 'txt' directory:", glob.glob(os.path.join(TRANSCRIPT_DIR, 'txt', '*.txt')))

        # Adjusted the way transcript_txt_path is constructed
        vid_basename = os.path.splitext(vid_fname)[0]
        transcript_txt_path = os.path.join(TRANSCRIPT_DIR, 'txt', vid_basename + '.txt')
        print(f"Looking for transcript at: {transcript_txt_path}")

        # Debug: Check if the file exists
        if not os.path.isfile(transcript_txt_path):
            print(f"Transcript file not found: {transcript_txt_path}")
            continue
        else:
            print(f"Transcript file found: {transcript_txt_path}")

        with open(transcript_txt_path, "r") as text_file:
            TRANSCRIPT = text_file.read()

        if pd.isnull(TRANSCRIPT):
            TRANSCRIPT = 'null, as no words are spoken in the ad'

        for this_frame_fpath in glob.glob(os.path.join(input_directory, vid_basename + '*')):
            totcount_of_frames_processed_thisproc += 1

            output_file_name = os.path.basename(this_frame_fpath) + '.txt'
            output_file_path = os.path.join(output_directory, output_file_name)

            if output_file_path in already_donebyGPT_frames:
                already_done += 1
                continue

            try:
                time0 = datetime.now()
                result = send_frame_to_gpt(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT)

                with open(output_file_path, 'w') as outfile:
                    outfile.write(result)
                print(this_frame_fpath, result, (datetime.now() - time0).total_seconds(),
                      'local workload', local_count, 'of', len(local_mastercsv_idx_split))
                SUCCESS = True

            except Exception as e:
                print('\nError on', os.path.basename(this_frame_fpath), e)

    print('Rank', rank, 'attempted to describe a total of',
          totcount_of_frames_processed_thisproc, 'video stills. Already done of these =', already_done)
