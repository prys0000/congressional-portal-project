import os
import sys
os.environ["NUMEXPR_MAX_THREADS"] = "272"

print("Arguments received:", sys.argv)

import openai
import numpy as np
import pandas as pd
from datetime import datetime
from time import sleep
import glob
from mpi4py import MPI

"""
This script summarizes videos in parallel.
"""

# Ensure the correct number of command-line arguments
if len(sys.argv) != 6:
    print("Usage: python step4_summarize_vids_parallel.py <TRANSCRIPT_DIR> <FRAME_DESC_SPEECH_DIR> "
          "<FRAME_DESC_REG_DIR> <VIDEO_DIR> <METADATA_FILE>")
    sys.exit(1)

TRANSCRIPT_DIR = sys.argv[1].replace('\\', '/')
FRAME_DESC_SPEECH_DIR = sys.argv[2]
FRAME_DESC_REG_DIR = sys.argv[3]
VIDEO_DIR = sys.argv[4]
METADATA_FNAME = os.path.abspath(sys.argv[5])

print(f"Transcript directory is set to: {TRANSCRIPT_DIR}")
print(f"Video directory is set to: {VIDEO_DIR}")

# Use your actual API key enclosed in quotes
openai.api_key = "sk-iX3KJn-Ob_M6_yoynV3Jq8D4SHqd4ZzPZSgVHGtQrHT3BlbkFJGg0NmLFGe1pNHpLXNCtLF0xz9s3nneDumKi8F2Oy4A"

METADATA_FNAME = 'METADATA.csv'

def gpt_summarize_ad(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT, FRAMETIMES, FRAMEDESCRIPTIONS, response_wordcount=50):
    FRAMETIMES_argsort = np.argsort(FRAMETIMES)
    FRAMEDESCRIPTIONS_timesorted = np.asarray(FRAMEDESCRIPTIONS)[FRAMETIMES_argsort]

    prompt = (
        f'Provide a {response_wordcount}-word summary of a political television ad for the academic community. '
        f'Your summary should not exceed {response_wordcount} words. For context, this ad was for the {ELECTION_YEAR} '
        f'presidential campaign of {PARTY} candidate {CANDIDATE}. The transcript of the entire ad is:\n{TRANSCRIPT}\n\n'
        f'The ad video depicts a set of scenes that can be described as follows:\n\n' +
        '\n\n'.join([f'{idx+1}: {segment}' for idx, segment in enumerate(FRAMEDESCRIPTIONS_timesorted)])
    )
    if 'anti' in CANDIDATE.lower():
        prompt = (
            f'Provide a {response_wordcount}-word summary of a political television ad for the academic community. '
            f'Your summary should not exceed {response_wordcount} words. For context, this ad was for the {ELECTION_YEAR} '
            f'presidential election. This ad is anti-{CANDIDATE} and pro-{PARTY}. The transcript of the entire ad is:\n{TRANSCRIPT}\n\n'
            f'The ad video depicts a set of scenes that can be described as follows:\n\n' +
            '\n\n'.join([f'{idx+1}: {segment}' for idx, segment in enumerate(FRAMEDESCRIPTIONS_timesorted)])
        )
    print('\n\n\n', prompt, '\n')

    PROMPT_MESSAGES = [
        {"role": "user", "content": prompt}
    ]
    parameters = {
        "model": "gpt-4",
        "messages": PROMPT_MESSAGES,
        "max_tokens": 1000,
    }
    result = openai.ChatCompletion.create(**parameters)
    return result.choices[0].message.content

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    print(rank, size)

    # Create the output directory if it doesn't exist
    output_dir = "GPT_video_summaries"
    if rank == 0:
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
    comm.Barrier()

    already_summarized_videos = glob.glob(os.path.join(output_dir, '*.txt'))

    metadata_df = pd.read_csv(METADATA_FNAME)
    manuallabel_subset_df = metadata_df  # Placeholder for subsetting

    proc_time0 = datetime.now()
    local_errors = []

    indices = list(range(len(manuallabel_subset_df)))
    np.random.shuffle(indices)
    local_mastercsv_idx_split = np.array_split(indices, size)[rank]

    already_done = 0
    for local_count, idx in enumerate(local_mastercsv_idx_split):
        if local_count > 1:
            proc_elapsed_min = (datetime.now() - proc_time0).total_seconds() / 60.
            print('\nRank', rank, 'starting CSV row', idx, 'which is local workload', local_count + 1,
                  'of', len(local_mastercsv_idx_split), 'in', proc_elapsed_min, 'min;',
                  proc_elapsed_min * float(len(local_mastercsv_idx_split) - local_count) / float(local_count), 'mins remain')

        vid_fname = metadata_df['FILENAME'].values[idx]
        vid_basename = os.path.splitext(vid_fname)[0]  # Remove file extension
        local_vid_fpath = os.path.join('pres_ad_videos', vid_fname)

        summary_output_path = os.path.join(output_dir, vid_fname + '.txt')
        if summary_output_path in already_summarized_videos:
            already_done += 1
            continue

        PARTY = manuallabel_subset_df['PARTY'].values[idx]
        ELECTION_YEAR = str(manuallabel_subset_df['ELECTION'].values[idx])  # Ensure column name matches your CSV

        lastname = manuallabel_subset_df['LAST_NAME'].values[idx] if pd.notnull(manuallabel_subset_df['LAST_NAME'].values[idx]) else ''
        firstname = manuallabel_subset_df['FIRST_NAME'].values[idx] if pd.notnull(manuallabel_subset_df['FIRST_NAME'].values[idx]) else ''
        CANDIDATE = f"{firstname} {lastname}".strip()

        print("Files in transcript directory:", glob.glob(os.path.join(TRANSCRIPT_DIR, '*.txt')))


        # Construct the transcript file path
        transcript_txt_path = os.path.join(TRANSCRIPT_DIR, 'txt', vid_basename + '.txt')
        print(f"Looking for transcript at: {transcript_txt_path}")

        if not os.path.isfile(transcript_txt_path):
            print(f"Transcript file not found: {transcript_txt_path}")
            continue


        with open(transcript_txt_path, "r") as text_file:
            TRANSCRIPT = text_file.read()

        if pd.isnull(TRANSCRIPT):
            TRANSCRIPT = 'null, as no words are spoken in the ad'

        # Load frame descriptions for speech-centered frames
        FRAMETIMES_SEGMENTS = []
        FRAMEDESCRIPTIONS_SEGMENTS = []
        speech_desc_dir = 'GPT_frame_descriptions_speechcentered'
        for this_framedescription_fpath in glob.glob(os.path.join(speech_desc_dir, vid_basename + '*')):
            frametime = float(this_framedescription_fpath.split('_')[-1].split('.')[0])
            FRAMETIMES_SEGMENTS.append(frametime)
            with open(this_framedescription_fpath, 'r') as tmp:
                description = tmp.read()
                FRAMEDESCRIPTIONS_SEGMENTS.append(description)

        # Load frame descriptions for regular interval frames
        FRAMETIMES_REGSPACED = []
        FRAMEDESCRIPTIONS_REGSPACED = []
        reg_desc_dir = 'GPT_frame_descriptions_regintervals'
        for this_framedescription_fpath in glob.glob(os.path.join(reg_desc_dir, vid_basename + '*')):
            frametime = float(this_framedescription_fpath.split('_')[-1].split('.')[0])
            FRAMETIMES_REGSPACED.append(frametime)
            with open(this_framedescription_fpath, 'r') as tmp:
                description = tmp.read()
                FRAMEDESCRIPTIONS_REGSPACED.append(description)

        FRAMETIMES = FRAMETIMES_SEGMENTS + FRAMETIMES_REGSPACED
        FRAMEDESCRIPTIONS = FRAMEDESCRIPTIONS_SEGMENTS + FRAMEDESCRIPTIONS_REGSPACED

        if not FRAMEDESCRIPTIONS:
            print(f"No frame descriptions found for video: {vid_fname}")
            continue

        try:
            time0 = datetime.now()
            result = gpt_summarize_ad(ELECTION_YEAR, PARTY, CANDIDATE, TRANSCRIPT, FRAMETIMES, FRAMEDESCRIPTIONS)

            if not result.strip():
                raise Exception("Empty result from OpenAI!")

            with open(summary_output_path, 'w') as outfile:
                outfile.write(result)
            print('RESULT:\n', vid_fname, result,
                  'GPT Response time (sec):', (datetime.now() - time0).total_seconds())

        except Exception as e:
            print('\nError on', vid_fname, e)
            local_errors.append((e, rank, local_vid_fpath))

    print(local_errors)
    print('Rank', rank, 'attempted to summarize a total of',
          len(local_mastercsv_idx_split), 'videos. Already done =', already_done)
