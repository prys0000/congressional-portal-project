import numpy as np
import pandas as pd
from mpi4py import MPI
import subprocess
import os
import glob

# Ensure the use of raw string literals or proper path formatting for Windows
TRANSCRIPT_DIR = r"G:\AV\pres_ad_whisptranscripts"  # Raw string ensures correct path handling
METADATA_FNAME = r"G:\AV\METADATA.csv"
VIDEO_DIR = r"G:\AV\pres_ad_videos"

# Print the directories being used for transcripts and metadata to confirm they are correct
print(f"Using METADATA_FILE: {METADATA_FNAME}")
print(f"Using TRANSCRIPT_DIR: {TRANSCRIPT_DIR}")
print(f"Using VIDEO_DIR: {VIDEO_DIR}")

# Get the local transcription files
filepaths_transcripts_local = glob.glob(os.path.join(TRANSCRIPT_DIR, 'tsv', '*.tsv'))
transcribed_videos_local = [os.path.basename(x).split('.')[0] for x in filepaths_transcripts_local]

# Debugging step to confirm the found .tsv files
print(f"Found {len(transcribed_videos_local)} transcription files in the tsv directory.")

if __name__ == '__main__':
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()

    # Create keyframe storage directory if it doesn't already exist:
    if rank == 0:
        if not os.path.exists("keyframes_speechcentered"): 
            os.makedirs("keyframes_speechcentered")

    metadata_df = pd.read_csv(METADATA_FNAME)

    # Split the metadata across processes
    local_mastercsv_idx_split = np.array_split(list(range(len(metadata_df))), size)[rank]

    for idx in local_mastercsv_idx_split:
        vid_fname = metadata_df['FILENAME'].values[idx]
        tsv_path = os.path.join(TRANSCRIPT_DIR, 'tsv', vid_fname.split('.')[0] + '.tsv')
        local_vid_fpath = os.path.join(VIDEO_DIR, vid_fname)  # Define the local path to the video file
        
        print(f"Constructed TSV path for file: {tsv_path}")
        print(f"Constructed Video path for file: {local_vid_fpath}")

        if not os.path.isfile(tsv_path):
            print(f"ERROR: File not found at path: {tsv_path}")
            continue

        try:
            with open(tsv_path, 'r') as f:
                print(f"Successfully opened {tsv_path}")
                print(f"First 100 characters: {f.read(100)}")
            
            # Read the transcript and extract segment times
            tsv = pd.read_csv(tsv_path, sep='\t')

            segment_starts = tsv['start'].values
            segment_ends = tsv['end'].values
            segment_middles = [int(segment_starts[ii] + (segment_ends[ii] - segment_starts[ii]) / 2.0) for ii in range(len(segment_starts))]

            # Check if the last frame is already saved, skip if so
            last_image_path = os.path.join('keyframes_speechcentered', str(vid_fname.split('.')[0]) + "_" + str(segment_middles[-1]) + ".jpg")
            if os.path.isfile(last_image_path):
                print(f"Skipping {vid_fname}, keyframes already generated.")
                continue

            # Extract frames at the middle of each segment
            for fidx, frame_sample_time in enumerate(segment_middles):
                if frame_sample_time > metadata_df['DURATION'].values[idx] * 1000.:
                    continue

                image_output_fpath = os.path.join('keyframes_speechcentered', f"{vid_fname.split('.')[0]}_{frame_sample_time}.jpg")

                # Run ffmpeg to extract the frame
                result = subprocess.run(
                    ['ffmpeg', '-ss', str(frame_sample_time / 1000.), '-i', local_vid_fpath, '-frames:v', '1', image_output_fpath, '-y', '-hide_banner', '-loglevel', 'error'],
                    capture_output=True, text=True
                )

                # Check for ffmpeg errors
                if result.returncode != 0:
                    print(f"ERROR: ffmpeg failed for video {local_vid_fpath} at time {frame_sample_time / 1000.0}s.")
                    print(f"ffmpeg stderr: {result.stderr}")
                    continue  # Skip this frame if ffmpeg failed

                print(f"Saved frame to: {image_output_fpath}")

        except Exception as e:
            print(f"ERROR-opening {tsv_path}. Exception: {e}")
            continue
